#!/bin/sh
javac project5.java