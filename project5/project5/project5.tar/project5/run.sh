#!/bin/sh
 
java -cp guava-14.0.1.jar:. project5  $*